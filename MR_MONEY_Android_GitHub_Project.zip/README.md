# MR MONEY — Android Loan/Lending App

Package: `com.mrmoney.hisab`

## वर्तमान आधार
- Native Android/Kotlin project
- Offline-first architecture
- Lender/Admin dashboard foundation
- GitHub Actions से Debug APK build
- Customer Mode के लिए आगे अलग सुरक्षित view जोड़ा जाएगा

## GitHub पर डालना
1. इस ZIP को extract करें।
2. सभी files को GitHub repository में upload करें।
3. `.github/workflows/build-apk.yml` मौजूद रहने दें।
4. GitHub → Actions → **Build MR MONEY APK** → Run workflow.
5. Build पूरा होने पर Artifacts से APK लें।

## आगे के मॉड्यूल
- ग्राहक: नाम, मोबाइल, पता, फोटो/crop
- Contacts से नंबर चुनना
- Loan creation
- Simple/compound/fixed interest
- एक ग्राहक के लिए कई disbursement
- एक दिन में कई repayments
- Automatic principal/interest/due calculation
- तारीख/समय edit
- Installment schedule और reminders
- Customer App/Customer Mode
- PDF statement/share
- Backup/restore
- App lock/PIN
