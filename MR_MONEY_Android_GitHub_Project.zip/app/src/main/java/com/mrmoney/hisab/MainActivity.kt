package com.mrmoney.hisab

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var store: MoneyStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = MoneyStore(this)

        val summary = findViewById<android.widget.TextView>(R.id.tvSummary)
        summary.text = "ग्राहक: ${store.customerCount()}  •  कुल Loan: ₹${store.totalLoan()}  •  बाकी: ₹${store.totalDue()}"

        findViewById<Button>(R.id.btnAddCustomer).setOnClickListener {
            Toast.makeText(this, "अगला चरण: ग्राहक फॉर्म + फोटो + Contact", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnAddLoan).setOnClickListener {
            Toast.makeText(this, "अगला चरण: Loan और ब्याज एंट्री", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnPayment).setOnClickListener {
            Toast.makeText(this, "अगला चरण: कई बार भुगतान रिकॉर्ड", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnCustomers).setOnClickListener {
            Toast.makeText(this, "अगला चरण: ग्राहक/बकाया सूची", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnBackup).setOnClickListener {
            Toast.makeText(this, "Backup/Restore मॉड्यूल अगले चरण में", Toast.LENGTH_SHORT).show()
        }
    }
}
