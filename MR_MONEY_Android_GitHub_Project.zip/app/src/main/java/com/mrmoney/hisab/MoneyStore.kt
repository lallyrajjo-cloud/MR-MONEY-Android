package com.mrmoney.hisab

import android.content.Context

class MoneyStore(context: Context) {
    private val prefs = context.getSharedPreferences("mr_money", Context.MODE_PRIVATE)

    fun customerCount(): Int = prefs.getInt("customer_count", 0)
    fun totalLoan(): Long = prefs.getLong("total_loan", 0L)
    fun totalDue(): Long = prefs.getLong("total_due", 0L)
}
